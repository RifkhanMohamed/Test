import { Component, OnInit } from '@angular/core';
import {home} from '../model/home.model';
import { SharedserviceService } from 'app/sharedservices/sharedservice.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers:[SharedserviceService]

})
export class HomeComponent implements OnInit {
  home=new home();
  
  homeArray=[];
  activeIndex=-1;
  title='Create';
  serviceData: any;
  data: any;
  requests: any;
  private _http: any;
  constructor(
    private SharedserviceService:SharedserviceService
    ) { }
  

  ngOnInit() { 
    this.getData();
  }

  getData(){
    this.SharedserviceService.getData().subscribe(data=>
      {
        this.data=data.data;
        console.log(this.data);
      })
  }

  onSubmit()
  {
    if(this.activeIndex==-1){
      this.SharedserviceService.createData(this.home).subscribe(data=>{
        console.log(data);
        this.getData();
      })  
    }
    else{
      this.SharedserviceService.updateData(this.home).subscribe(data=>{
        this.getData();
      })
    }
    this.home=new home();
    this.title='Create';
    this.activeIndex=-1;
  }
  delete(j)
  {
    console.log(j);
    this.SharedserviceService.deleteData(j).subscribe(data=>{
      this.getData();
    })
  }
  edit(obj,index)
  {
    console.log("obj",obj);
    this.title='Update';
    this.home.name=obj.employee_name;
    this.home.salary=obj.employee_salary;
    this.home.age=obj.employee_age;
    this.home.id=obj.id;
    this.activeIndex=index;
  }
}
