import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import {ApproutingModule} from './app.routing.module';
import { SharedserviceService } from './sharedservices/sharedservice.service';
import { ViewdetailComponent } from './viewdetail/viewdetail.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    ViewdetailComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ApproutingModule,
    HttpModule
  ],
  providers: [SharedserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
