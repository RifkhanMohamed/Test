import { Injectable } from '@angular/core';
import {Http} from '@angular/http';
import 'rxjs/add/operator/map' ;
import { home } from 'app/model/home.model';

@Injectable()
export class SharedserviceService {
  dataArray=[];
  constructor(
    private http:Http
  ) { 
  }

  getData(){
    return this.http.get('http://dummy.restapiexample.com/api/v1/employees').map(res=>
      {
        console.log(res);
        return res.json()
      })
  }

  createData(info){
    return this.http.post('http://dummy.restapiexample.com/api/v1/create',info).map(res=>
      {
        console.log(res);
        return res.json()
      })
  }

  deleteData(id){
    
    return this.http.delete('http://dummy.restapiexample.com/api/v1/delete/'+id).map(res=>
      {
        console.log(res);
        return res.json()
      })
  }

  updateData(info){
    return this.http.put('http://dummy.restapiexample.com/api/v1/update/'+info.id,info).map(res=>
      {
        console.log(res);
        return res.json()
      })
  }

  getOne(id){
    return this.http.get('http://dummy.restapiexample.com/api/v1/employee/'+id).map(res=>
      {
        console.log(res);
        return res.json()
      })
  }
}
