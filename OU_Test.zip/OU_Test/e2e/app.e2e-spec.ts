import { OuTestPage } from './app.po';

describe('ou-test App', function() {
  let page: OuTestPage;

  beforeEach(() => {
    page = new OuTestPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
